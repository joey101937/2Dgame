/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BromTrainingGrounds;

import pkg2dgame.Game;
/**
 *LESSON: FOR-LOOPS and Local Variables
 * this is the lesson about the basic for-loop
 * 
 * CONCEPTS
 * -looping with a condition
 * -local variables
 * -fields or global variables 
 * 
 */
public class ObjectsLesson1 {
   
    
//here is our main method that runs unpon launch
    public static void main(String[] args) {
        
        /*
        Starting with for-loops:
        a for loop is a way to execute a given block of code repeatedly until a given boolean is false.
        for loops have three parts:
        1.StartingStatement
        2.condition
        3.endingStatement
        and are written like this:
        
        for(startingStatement ; condition ; endingStatement){
        <code>
        }
        
        the starting statement is a line of code executed at the beginning of the for-loop once
        the condition is a boolean that determines if we continue looping (true = loop)
        the endingStatement is a line of code that is run every time a loop completes
        
        for example
        
        for(int i = 0; i < 3; i++){
        System.out.println("test");
        }
        
        would print "test" three times.
        int 1 = 3; is the startingStatement
        i < 3; is the condition
        i++; is the endingStatement
        
        first we make a variable i = 0. 
        then we print test.
        then we execute our endingStatement
        now we check the condition to see if we do it again.
        i = 1 now, because 0+1=1. 1 is indeed less than 3 so we loop again.
        now we print test and increse i again.
        2 is still less than 3 so we loop again.
        print test for the third time and increment i.
        3 is not greater than 3, so we break the loop as our condition becomes false
        
        */   
        
            for(int i = 0; i < 3; i++){
                System.out.println("test");
            }
            
            
        
        
    }
}
